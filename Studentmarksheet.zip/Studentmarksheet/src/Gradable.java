public interface Gradable {
    String calculateGrade();
}
